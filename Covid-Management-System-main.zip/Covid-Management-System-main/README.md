# Covid-Management-System
This is a web based Covid-19 management system. It is implemented using HTML, CSS, JavaScript, PHP and Bootstrap.
To run this, save all the files in a folder in 'htdocs' folder of 'xampp'. Then run xampp and open 'homepage.html' file from there. Then you can switch to any page from there.
